module veriYapilariOdev7 {
}