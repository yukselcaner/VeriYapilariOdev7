package veriYapilariOdev7;

import java.util.Scanner;

public class Main {
	/** 
	 * @author Yüksel Caner MÜLAZIMOĞLU - 02210201034
	 */
	public static void main(String[] args) {
		//String metin ="aaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbccccccccccddddddddeeeeeeeeee";
		System.out.print("metin:\n");
		String metin = new Scanner(System.in).nextLine();

		int[] frekans = new int[35];
		String[] harfler = new String[35];

		int b = 0;
		harfler[0] = metin.substring(0, 1);
		int harfSayisi = 1;

		for (int i = 1; i < metin.length() + 1; i++) {
			boolean var = false;
			for (int x = 0; x < harfSayisi; x++) {
				if (metin.substring(b, i).equals(harfler[x])) {
					var = true;
				}
			}
			if (!var) {
				harfler[harfSayisi] = metin.substring(b, i);
				harfSayisi++;
			}
			b++;
		}
		int harfS = harfSayisi;

		b = 0;
		for (int i = 1; i < metin.length() + 1; i++) {
			for (int x = 0; x < harfSayisi; x++) {
				if (metin.substring(b, i).equals(harfler[x])) {
					frekans[x]++;
				}
			}
			b++;
		}

		Main m = new Main();
		m.sirala(frekans, harfler, harfSayisi);

		int h = 0;
		while (harfler[h * 2 + 1] != null) {
			frekans[harfSayisi] = frekans[h * 2] + frekans[h * 2 + 1];

			for (int l = 0; l < harfSayisi; l++) {
				if (harfler[h * 2].substring(harfler[h * 2].length() - 1, harfler[h * 2].length()).equals(harfler[l])) {
					for (int r = 0; r < harfSayisi; r++) {
						if (harfler[h * 2 + 1].substring(0, 1).equals(harfler[r])) {
							if (frekans[r] > frekans[l]) {
								harfler[harfSayisi] = harfler[h * 2] + harfler[h * 2 + 1];
							} else {
								harfler[harfSayisi] = harfler[h * 2 + 1] + harfler[h * 2];
							}
						}
					}
					break;
				}
			}
			harfSayisi++;
			m.sirala(frekans, harfler, harfSayisi);
			h++;
		}

		String[] sifre = new String[harfSayisi];

		for (int i = 0; i < harfS; i++) {
			for (int j = i; j < harfSayisi; j++) {
				if (harfler[j].length() == 1) {
					sifre[i] = harfler[j] + "-";

					String kelime = harfler[j];
					for (int k = j; k < harfSayisi; k++) {
						if (kelime.length() <= harfler[k].length()
								&& kelime.equals(harfler[k].substring(0, kelime.length()))
								&& kelime.equals(harfler[k]) == false) {
							//System.out.println(kelime + " " + harfler[k] + "0");
							kelime = harfler[k];
							sifre[i] += "0";
						}
						if (kelime.length() <= harfler[k].length() && kelime.equals(
								harfler[k].substring(harfler[k].length() - kelime.length(), harfler[k].length()))
								&& kelime.equals(harfler[k]) == false) {
							//System.out.println(kelime + " " + harfler[k] + "1");
							kelime = harfler[k];
							sifre[i] += "1";
						}

					}
					break;
				}
			}
		}

		System.out.println("---------------------");
		for (int i = 0; i < harfS; i++) {
			System.out.println(sifre[i]);
			//System.out.println(sifre[i] + "\t" + harfler[i] + "\t" + frekans[i]);
		}
	}

	public void sirala(int[] frekans, String[] harfler, int harfSayisi) {
		for (int i = 0; i < harfSayisi; i++) {
			for (int j = 0; j < harfSayisi - 1; j++) {
				if (frekans[j] > frekans[j + 1]) {
					int tmp = frekans[j];
					frekans[j] = frekans[j + 1];
					frekans[j + 1] = tmp;

					String harf = harfler[j];
					harfler[j] = harfler[j + 1];
					harfler[j + 1] = harf;
				}
			}
		}
	}
}

